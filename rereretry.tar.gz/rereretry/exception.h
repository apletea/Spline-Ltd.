#pragma once

#include <stdio.h>
#include <string>
#include <system_error>

#define exc_get_what(what) ("[" + std::string(__FILE__) + " : " + std::to_string(__LINE__) + "] " + std::string(__func__) + ". " + std::string(what))
#define exc_log_what(what)                                    \
    {                                                         \
        fprintf(stderr, (exc_get_what(what) + "\n").c_str()); \
    }

#define throw_this                                                                \
    {                                                                             \
        throw std::system_error(errno, std::system_category(), exc_get_what("")); \
    }
#define throw_what(what)                                                            \
    {                                                                               \
        throw std::system_error(errno, std::system_category(), exc_get_what(what)); \
    }

#define throw_what_global(what) \
    {                           \
        throw;                  \
    }
