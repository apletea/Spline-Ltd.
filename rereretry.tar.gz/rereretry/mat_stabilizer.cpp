#include "mat_stabilizer.h"
#include <iomanip>
mat_stabilizer::mat_stabilizer(eye::Mat)
{

    std::unique_ptr<nvx::VideoStabilizer> stblzr(nvx::VideoStabilizer::createImageBasedVStab(context, params));
    this->stabilizer = std::move(stbzr);
}



