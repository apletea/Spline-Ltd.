#pragma once
#include "rect.h"
#include "exception.h"
#include <memory>
#include <string.h>

namespace eye {
#define CV_CN_MAX 512
#define CV_CN_SHIFT 3
#define CV_DEPTH_MAX (1 << CV_CN_SHIFT)

#define CV_8U 0
#define CV_8S 1
#define CV_16U 2
#define CV_16S 3
#define CV_32S 4
#define CV_32F 5
#define CV_64F 6
#define CV_USRTYPE1 7

#define CV_MAT_DEPTH_MASK (CV_DEPTH_MAX - 1)
#define CV_MAT_DEPTH(flags) ((flags)&CV_MAT_DEPTH_MASK)

#define CV_MAKETYPE(depth, cn) (CV_MAT_DEPTH(depth) + (((cn)-1) << CV_CN_SHIFT))
#define CV_MAKE_TYPE CV_MAKETYPE

#define CV_GET_CHANNELS(type) ((1 + (type >> CV_CN_SHIFT)))
static inline int CV_GET_BPP(int type)
{
    auto chans = CV_GET_CHANNELS(type);
    type &= 0x3;
    switch (type) {
    case 0:
    case 1:
        return chans * 1;
    case 2:
    case 3:
        return chans * 2;
    case 4:
    case 5:
        return chans * 4;
    case 6:
        return chans * 8;
    default:
        return 0;
    }
}

#define CV_8UC1 CV_MAKETYPE(CV_8U, 1)
#define CV_8UC2 CV_MAKETYPE(CV_8U, 2)
#define CV_8UC3 CV_MAKETYPE(CV_8U, 3)
#define CV_8UC4 CV_MAKETYPE(CV_8U, 4)
#define CV_8UC(n) CV_MAKETYPE(CV_8U, (n))

#define CV_8SC1 CV_MAKETYPE(CV_8S, 1)
#define CV_8SC2 CV_MAKETYPE(CV_8S, 2)
#define CV_8SC3 CV_MAKETYPE(CV_8S, 3)
#define CV_8SC4 CV_MAKETYPE(CV_8S, 4)
#define CV_8SC(n) CV_MAKETYPE(CV_8S, (n))

#define CV_16UC1 CV_MAKETYPE(CV_16U, 1)
#define CV_16UC2 CV_MAKETYPE(CV_16U, 2)
#define CV_16UC3 CV_MAKETYPE(CV_16U, 3)
#define CV_16UC4 CV_MAKETYPE(CV_16U, 4)
#define CV_16UC(n) CV_MAKETYPE(CV_16U, (n))

#define CV_16SC1 CV_MAKETYPE(CV_16S, 1)
#define CV_16SC2 CV_MAKETYPE(CV_16S, 2)
#define CV_16SC3 CV_MAKETYPE(CV_16S, 3)
#define CV_16SC4 CV_MAKETYPE(CV_16S, 4)
#define CV_16SC(n) CV_MAKETYPE(CV_16S, (n))

#define CV_32SC1 CV_MAKETYPE(CV_32S, 1)
#define CV_32SC2 CV_MAKETYPE(CV_32S, 2)
#define CV_32SC3 CV_MAKETYPE(CV_32S, 3)
#define CV_32SC4 CV_MAKETYPE(CV_32S, 4)
#define CV_32SC(n) CV_MAKETYPE(CV_32S, (n))

#define CV_32FC1 CV_MAKETYPE(CV_32F, 1)
#define CV_32FC2 CV_MAKETYPE(CV_32F, 2)
#define CV_32FC3 CV_MAKETYPE(CV_32F, 3)
#define CV_32FC4 CV_MAKETYPE(CV_32F, 4)
#define CV_32FC(n) CV_MAKETYPE(CV_32F, (n))

#define CV_64FC1 CV_MAKETYPE(CV_64F, 1)
#define CV_64FC2 CV_MAKETYPE(CV_64F, 2)
#define CV_64FC3 CV_MAKETYPE(CV_64F, 3)
#define CV_64FC4 CV_MAKETYPE(CV_64F, 4)
#define CV_64FC(n) CV_MAKETYPE(CV_64F, (n))

template <typename T>
class Mat {
private:
    bool _isMemoryOwner;
    int _cols;
    int _rows;
    int _channels;
    T* _first = nullptr;
    T* _last = nullptr;

    void init()
    {
        // release();
        if (_isMemoryOwner) {
            _first = (T*)malloc(size());
        }
        _last = _first + total();
    }

public:
    Mat(Mat<T> const&) = delete;

    Mat(int rows, int cols, int channels = 1)
        : _isMemoryOwner(true)
        , _cols(cols)
        , _rows(rows)
        , _channels(channels)
    {
        init();
    }

    Mat(int rows, int cols, int channels, void* data)
        : _isMemoryOwner(false)
        , _cols(cols)
        , _rows(rows)
        , _channels(channels)
        , _first((T*)data)
    {
        init();
    }

    static std::shared_ptr<Mat<T> > make(int rows, int cols, int channels = 1)
    {
        return std::make_shared<Mat<T> >(rows, cols, channels);
    }

    static std::shared_ptr<Mat<T> > make(int rows, int cols, int channels,
        void* data)
    {
        return std::make_shared<Mat<T> >(rows, cols, channels, data);
    }

    ~Mat() { release(); }

    void release()
    {
        if (_isMemoryOwner && _first != nullptr) {
            free(_first);
            _first = nullptr;
            _last = nullptr;
        }
    }

    int cols() const { return _cols; }

    int rows() const { return _rows; }

    int channels() const { return _channels; }

    int pixSize() const { return sizeof(T) * _channels; }

    int bpp() const { return pixSize() * 8; }

    int step() const { return sizeof(T); }

    int stride() const { return _cols * pixSize(); }

    int total() const { return _cols * _rows; }

    size_t size() const { return total() * pixSize(); }

    int cvDepth() const;

    int type() const
    {
        int depth = cvDepth();
        int t = CV_MAKETYPE(depth, _channels);
        return t;
    }

    uint8_t* beg() const { return (uint8_t*)_first; }

    uint8_t* end() const { return (uint8_t*)_last; }

    T* first() const { return _first; }

    T* last() const { return _last; }

    T* at(int x, int y) { return _first + y * _cols * _channels + x; }

    bool isSameSize(int rows, int cols) const
    {
        return _rows == rows && _cols == cols && _first != nullptr;
    }

    template <typename TOther>
    bool isSameSize(Mat<TOther>& other) const
    {
        return isSameSize(other.rows(), other.cols());
    }

    void* ptr(int position) const { return (void*)(_first + position); }

    void create(int rows, int cols)
    {
        if (isSameSize(rows, cols))
            return;

        release();

        _rows = rows;
        _cols = cols;
        init();
    }

    void create(const Mat<T>& reference)
    {
        create(reference.rows(), reference.cols());
    }

    template <typename TOther>
    void create(const Mat<TOther>& reference)
    {
        create(reference.rows(), reference.cols());
    }

    void copyTo(Mat<T>& other) const
    {
        other.create(*this);
        memcpy(other.beg(), beg(), size());
    }

    void setTo(T value)
    {
        auto cur = _first;
        while (cur < _last) {
            *cur = value;
            ++cur;
        }
    }

    void setTo(T value, const Rect& roi)
    {
        auto tl = roi.tl();
        auto br = roi.br();
        for (int y = tl.y; y < br.y; y++) {
            auto ptr = first() + cols() * y + tl.x;
            auto end = ptr + roi.width;
            while (ptr < end) {
                *ptr = value;
                ++ptr;
            }
        }
    }

    void clear() const { memset(beg(), 0, size()); }
};

template <>
inline int Mat<uint8_t>::cvDepth() const
{
    return 0;
}
template <>
inline int Mat<int8_t>::cvDepth() const
{
    return 1;
}
template <>
inline int Mat<uint16_t>::cvDepth() const
{
    return 2;
}
template <>
inline int Mat<int16_t>::cvDepth() const
{
    return 3;
}
template <>
inline int Mat<uint32_t>::cvDepth() const
{
    return 4;
}
template <>
inline int Mat<float>::cvDepth() const
{
    return 5;
}
template <>
inline int Mat<double>::cvDepth() const
{
    return 6;
}
template <typename T>
inline int Mat<T>::cvDepth() const
{
    return 7;
}
}
