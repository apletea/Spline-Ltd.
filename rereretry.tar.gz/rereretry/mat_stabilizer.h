#ifndef MAT_STABILIZER_H
#define MAT_STABILIZER_H

#include <NVX/nvx.h>
#include "mat.h"
#include <cassert>
#include "stabilizer.hpp"
#include <OVX/FrameSourceOVX.hpp>
#include <OVX/RenderOVX.hpp>
#include <OVX/UtilityOVX.hpp>


template <typename T>
class mat_stabilizer
{
private:
    std::unique_ptr<nvx::VideoStabilizer> stabilizer;
    std::shared_ptr<eye::Mat<T> >  frame;
    ovxio::ContextGuard context;


    inline  vx_df_image convertEyeMatTypeToVXImageFormat (int mat_type)
    {
        switch(mat_type)
        {
        case CV_8UC1 :
            return VX_DF_IMAGE_U8;
        case CV_16UC1 :
            return VX_DF_IMAGE_U16;
        case CV_16SC1:
            return VX_DF_IMAGE_S16;
        case CV_32SC1:
            return  VX_DF_IMAGE_S32;
        case CV_32FC1:
            return NVX_DF_IMAGE_F32;
        case CV_32FC2:
            return NVX_DF_IMAGE_2F32;
        case CV_16SC2:
            return NVX_DF_IMAGE_2S16;
        case CV_8UC3:
            return VX_DF_IMAGE_RGB;
        case CV_8UC4:
            return VX_DF_IMAGE_RGBX;
        case CV_16SC3:
            return NVX_DF_IMAGE_RGB16;
        }
        throw 1;
        return 0;
    }

    inline int  convertVxImageFormatToEyeMat(vx_df_image format, vx_uint32 plane_index = 0)
    {
        switch (format)
        {
        case VX_DF_IMAGE_U8:
        case VX_DF_IMAGE_YUV4:
        case VX_DF_IMAGE_IYUV:
            return  CV_8UC1;
        case VX_DF_IMAGE_U16:
            return  CV_16UC1;
        case VX_DF_IMAGE_S16:
            return CV_16SC1;
        case VX_DF_IMAGE_U32:
        case VX_DF_IMAGE_S32:
            return CV_32SC1;
        case NVX_DF_IMAGE_F32:
            return  CV_32FC1;
        case NVX_DF_IMAGE_2F32:
            return  CV_32FC2;
        case NVX_DF_IMAGE_2S16:
            return CV_16SC2;
        case VX_DF_IMAGE_UYVY:
        case VX_DF_IMAGE_YUYV:
            return CV_8UC2;
        case VX_DF_IMAGE_RGB:
            return CV_8UC3;
        case NVX_DF_IMAGE_RGB16:
            return CV_16SC3;
        case VX_DF_IMAGE_RGBX:
            return CV_8UC4;
        case VX_DF_IMAGE_NV12:
        case VX_DF_IMAGE_NV21:
            return plane_index == 0 ? CV_8UC1 : CV_8UC2;
        }
        throw 2;
        return 0;
    }





    mat_stabilizer();
public:

    mat_stabilizer(unsigned numOfSmoothingFrames, float cropMargin)
    {

        vxRegisterLogCallback(context, &ovxio::stdoutLogCallback, vx_false_e);
        vxDirective(context, VX_DIRECTIVE_ENABLE_PERFORMANCE);


        nvx::VideoStabilizer::VideoStabilizerParams params;
        params.numOfSmoothingFrames_ = numOfSmoothingFrames;
        params.cropMargin_ = cropMargin;
        std::unique_ptr<nvx::VideoStabilizer> stblzr(nvx::VideoStabilizer::createImageBasedVStab(this->context, params));
        this->stabilizer = std::move(stblzr);

    }

    void first_frame(eye::Mat<T> & first_frame)
    {
        vx_image converted_frame = this->fromEyeMatToVxImage(first_frame);
        this->stabilizer->init(converted_frame);
    }

    eye::Mat<T>& get_stabilized_frame()
    {
        vx_image img = this->stabilizer->getStabilizedFrame();
        this->frame = this->fromVxImageToEyeMat(img);
        return *this->frame;
    }

    void procces_frame(eye::Mat<T>& frame)
    {
        *this->frame = frame;
        vx_image img = this->fromEyeMatToVxImage(*this->frame);
        this->stabilizer->process(img);
    }

    inline vx_image fromEyeMatToVxImage(const eye::Mat<T> & mat)
    {
        vx_df_image format = convertEyeMatTypeToVXImageFormat(mat.type());

        vx_imagepatch_addressing_t addrs[1];
        addrs[0].dim_x = mat.cols();
        addrs[0].dim_y = mat.rows();
        addrs[0].stride_x = static_cast<vx_int32>(mat.pixSize()); //todo
        addrs[0].stride_y = static_cast<vx_int32>(addrs[0].dim_x*addrs[0].stride_x);

        void * ptrs[1] = { mat.first()};

        vx_image img = vxCreateImageFromHandle(this->context, format, addrs, ptrs, VX_MEMORY_TYPE_HOST);
        assert(vxGetStatus((vx_reference)img) == VX_SUCCESS);

        return img;
    }


    inline std::shared_ptr<eye::Mat<T> > fromVxImageToEyeMat( vx_image image)
    {
        vx_status status = VX_SUCCESS;
        vx_rectangle_t rect_;

        rect_.start_x = rect_.start_y = 0;
        status = vxQueryImage(image, VX_IMAGE_ATTRIBUTE_WIDTH, &rect_.end_x, sizeof(rect_.end_x));
        assert(status == VX_SUCCESS);

        status = vxQueryImage(image, VX_IMAGE_ATTRIBUTE_HEIGHT, &rect_.end_y, sizeof(rect_.end_y));
        assert(status == VX_SUCCESS);

        vx_df_image format = VX_DF_IMAGE_VIRT;
        status = vxQueryImage(image, VX_IMAGE_ATTRIBUTE_FORMAT, &format, sizeof(format));
        assert(status == VX_SUCCESS);

       // int type = convertVxImageFormatToEyeMat(format);
        void *ptr = NULL;
        vx_imagepatch_addressing_t addr;
        vx_map_id map_id_;
        status = vxMapImagePatch(image, &rect_, 0, &map_id_, &addr, &ptr, VX_READ_AND_WRITE, VX_MEMORY_TYPE_HOST, VX_NOGAP_X);
        assert(status == VX_SUCCESS);

        int cols = addr.dim_x * addr.scale_x / VX_SCALE_UNITY;
        int rows = addr.dim_y * addr.scale_y / VX_SCALE_UNITY;
        std::shared_ptr<eye::Mat<T> > stabilized_frame (eye::Mat<T>::make(rows, cols, 3 ,ptr));
        return stabilized_frame;
    }
};

#endif // MAT_STABILIZER_H
