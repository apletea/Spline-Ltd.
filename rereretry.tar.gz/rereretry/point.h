#pragma once
#include "vec.h"
#include <math.h>

namespace eye {
template <typename T>
class Point_ {
public:
    typedef T value_type;

    // various constructors
    Point_();
    Point_(T _x, T _y);
    Point_(const Point_& pt);
    //		Point_(const Vec<T, 2>& v);

    Point_& operator=(const Point_& pt);
    //! conversion to another data type
    template <typename T2>
    operator Point_<T2>() const;

    //! conversion to the old-style C structures
    //		operator Vec<T, 2>() const;

    //! dot product
    T dot(const Point_& pt) const;
    //! dot product computed in double-precision arithmetics
    double ddot(const Point_& pt) const;
    //! cross-product
    double cross(const Point_& pt) const;
    //! checks whether the point is inside the specified rectangle
    //		bool inside(const Rect_<T>& r) const;

    T x, y; //< the point coordinates
};

typedef Point_<int> Point2i;
typedef Point_<float> Point2f;
typedef Point_<double> Point2d;
typedef Point2i Point;

template <typename T>
inline Point_<T>::Point_()
    : x(0)
    , y(0)
{
}

template <typename T>
inline Point_<T>::Point_(T _x, T _y)
    : x(_x)
    , y(_y)
{
}

template <typename T>
inline Point_<T>::Point_(const Point_& pt)
    : x(pt.x)
    , y(pt.y)
{
}

//	template<typename T> inline
//	Point_<T>::Point_(const Vec<T, 2>& v)
//		: x(v[0])
//		, y(v[1]) {}

template <typename T>
inline Point_<T>& Point_<T>::operator=(const Point_& pt)
{
    x = pt.x;
    y = pt.y;
    return *this;
}

template <typename T>
template <typename T2>
inline Point_<T>::operator Point_<T2>() const
{
    //todo
    return Point_<T2>(x, y);
    //throw;
    //return Point_<T2>(saturate_cast<T2>(x), saturate_cast<T2>(y));
}

//todo
//	template<typename T> inline
//	Point_<T>::operator Vec<T, 2>() const
//	{
//		return Vec<T, 2>(x, y);
//	}

template <typename T>
inline T Point_<T>::dot(const Point_& pt) const
{
    return x * pt.x + y * pt.y;
}

template <typename T>
inline double Point_<T>::ddot(const Point_& pt) const
{
    return (double)x * pt.x + (double)y * pt.y;
}

template <typename T>
inline double Point_<T>::cross(const Point_& pt) const
{
    return (double)x * pt.y - (double)y * pt.x;
}

//template<typename T> inline bool
//Point_<T>::inside(const Rect_<T>& r) const
//{
//	return r.contains(*this);
//}

template <typename T>
static inline Point_<T>& operator+=(Point_<T>& a, const Point_<T>& b)
{
    a.x += b.x;
    a.y += b.y;
    return a;
}

template <typename T>
static inline Point_<T>& operator-=(Point_<T>& a, const Point_<T>& b)
{
    a.x -= b.x;
    a.y -= b.y;
    return a;
}

template <typename T>
static inline Point_<T>& operator*=(Point_<T>& a, int b)
{
    a.x = a.x * b;
    a.y = a.y * b;
    return a;
}

template <typename T>
static inline Point_<T>& operator*=(Point_<T>& a, float b)
{
    a.x = a.x * b;
    a.y = a.y * b;
    return a;
}

template <typename T>
static inline Point_<T>& operator*=(Point_<T>& a, double b)
{
    a.x = a.x * b;
    a.y = a.y * b;
    return a;
}

template <typename T>
static inline Point_<T>& operator/=(Point_<T>& a, int b)
{
    a.x = a.x / b;
    a.y = a.y / b;
    return a;
}

template <typename T>
static inline Point_<T>& operator/=(Point_<T>& a, float b)
{
    a.x = a.x / b;
    a.y = a.y / b;
    return a;
}

template <typename T>
static inline Point_<T>& operator/=(Point_<T>& a, double b)
{
    a.x = a.x / b;
    a.y = a.y / b;
    return a;
}

template <typename T>
static inline double norm(const Point_<T>& pt)
{
    return sqrt((double)pt.x * pt.x + (double)pt.y * pt.y);
}

template <typename T>
static inline bool operator==(const Point_<T>& a, const Point_<T>& b)
{
    return a.x == b.x && a.y == b.y;
}

template <typename T>
static inline bool operator!=(const Point_<T>& a, const Point_<T>& b)
{
    return a.x != b.x || a.y != b.y;
}

template <typename T>
static inline Point_<T> operator+(const Point_<T>& a, const Point_<T>& b)
{
    return Point_<T>(a.x + b.x, a.y + b.y);
}

template <typename T>
static inline Point_<T> operator-(const Point_<T>& a, const Point_<T>& b)
{
    return Point_<T>(a.x - b.x, a.y - b.y);
}

template <typename T>
static inline Point_<T> operator-(const Point_<T>& a)
{
    return Point_<T>(-a.x, -a.y);
}

template <typename T>
static inline Point_<T> operator*(const Point_<T>& a, int b)
{
    return Point_<T>(a.x * b, a.y * b);
}

template <typename T>
static inline Point_<T> operator*(int a, const Point_<T>& b)
{
    return Point_<T>(b.x * a, b.y * a);
}

template <typename T>
static inline Point_<T> operator*(const Point_<T>& a, float b)
{
    return Point_<T>(a.x * b, a.y * b);
}

template <typename T>
static inline Point_<T> operator*(float a, const Point_<T>& b)
{
    return Point_<T>(b.x * a, b.y * a);
}

template <typename T>
static inline Point_<T> operator*(const Point_<T>& a, double b)
{
    return Point_<T>(a.x * b, a.y * b);
}

template <typename T>
static inline Point_<T> operator*(double a, const Point_<T>& b)
{
    return Point_<T>(b.x * a, b.y * a);
}

template <typename T>
static inline Point_<T> operator/(const Point_<T>& a, int b)
{
    Point_<T> tmp(a);
    tmp /= b;
    return tmp;
}

template <typename T>
static inline Point_<T> operator/(const Point_<T>& a, float b)
{
    Point_<T> tmp(a);
    tmp /= b;
    return tmp;
}

template <typename T>
static inline Point_<T> operator/(const Point_<T>& a, double b)
{
    Point_<T> tmp(a);
    tmp /= b;
    return tmp;
}
}
